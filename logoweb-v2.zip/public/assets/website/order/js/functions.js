﻿$(document).ready(function () {
  $(".listpacks ul").mCustomScrollbar({
      scrollButtons: {enable: true},
      theme:"dark-3",
      scrollbarPosition: "outside"
  });
});