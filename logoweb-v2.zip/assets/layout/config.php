<?php
$phone = '(312) 943-9875';
$phone_link = 'tel:+13129439875';
$email = 'info@logovisioneer.com';
$email_link = 'mailto:info@logovisioneer.com';
$address = '1S280 summit avenue Unit E2 Suite 1d , Oakbrook terrace ,Illinois 60181';


