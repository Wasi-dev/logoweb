<section class="counter-sec">
   <div class="container-fluid">
      <div class="counter-main">
         <div class="counter-head-box">
            <h2>hitting <br /> new records</h2>
         </div>
         <div class="counter-main-box counter-responsive-slider" id="counter">
            <div class="counter-box">
               <div class="count">
                  <h3 class="counter-value" data-count="5000">0</h3>
                  <i class="fa fa-plus" aria-hidden="true"></i>
               </div>
               <p>happy customers</p>
            </div>
            <div class="counter-box">
               <div class="count">
                  <h3 class="counter-value" data-count="800">0</h3>
                  <i class="fa fa-plus" aria-hidden="true"></i>
               </div>
               <p>experienced designers</p>
            </div>
            <div class="counter-box">
               <div class="count">
                  <h3 class="counter-value" data-count="10">0</h3>
                  <i class="fa fa-plus" aria-hidden="true"></i>
               </div>
               <p>years in the industry</p>
            </div>
            <div class="counter-box">
               <div class="count">
                  <h3 class="counter-value" data-count="4959">0</h3>
                  <i class="fa fa-plus" aria-hidden="true"></i>
               </div>
               <p>website designed</p>
            </div>
            <div class="counter-box">
               <div class="count">
                  <h3 class="counter-value" data-count="7869">0</h3>
                  <i class="fa fa-plus" aria-hidden="true"></i>
               </div>
               <p>logo designed</p>
            </div>
         </div>
         <div class="btn-portfolio-box">
<a class="pkg_btn btn btn-portfolio" data-sku="Get Started Now" data-toggle="modal" data-target="#req_qoute">Get Started Now</a>
         </div>
      </div>
   </div>
</section>